/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ejemplo208;

import java.util.Random;
import javax.swing.JLabel;
/*
UNIVERSIDAD AUTONOMA DEL ESTADO DE MEXICO
CENTRO UNIVERSITARIO UAEM ZUMPANGO
INGENIERIA EN COMPUTACION
PROGRAMACION AVANZADA 2018-B

DESCRIPCION: 

ARCHIVO: Corredor.java

FECHA: 18/Octubre/2018
ALUMNOS(S): Juan Manuel Manjarrez Palacios
PROFESOR: ASDRUBAL LOPEZ CHAU
*/
public class Corredor implements Runnable {
    
    private int ancho= 0;

    public int getAncho() {
        return ancho;
    }

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }
    JLabel label;
    private RecursoCompartido recursoCompartido;
    
    @Override
    public void run() {
        //int vueltas = 0;
        Random r = new Random(System.nanoTime());
        int avance = 0;
        while (avance < ancho) {
            if (r.nextInt(100) < 50) {
                avance++;
            } else {
                avance += r.nextInt(3);
            }
            label.setLocation(avance, label.getY());
            try {
                Thread.sleep(10 + r.nextInt(100));
            } catch (InterruptedException ex) {
            }
        }
        recursoCompartido.setNameWinner(label.getText());
        label.setLocation(10, 20);
    }

    public Corredor(JLabel label) {
        this.label = label;
    }
    
    public Corredor(JLabel label, RecursoCompartido recursoCompartido, int ancho) {
        this(label);
        this.ancho = ancho;
        this.recursoCompartido = recursoCompartido;
    }
    
    public RecursoCompartido getRecursoCompartido() {
        return recursoCompartido;
    }

    public void setRecursoCompartido(RecursoCompartido recursoCompartido) {
        this.recursoCompartido = recursoCompartido;
    }
    
}
